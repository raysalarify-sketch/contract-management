"""
?�드 ?�이???�성 커맨??python manage.py seed_data
"""
from django.core.management.base import BaseCommand
from accounts.models import User, Company, LandlordProfile, AgentProfile
from properties.models import Property, PropertyTag


SEED_PROPERTIES = [
    {"name":"?��????�스?��? 102??1203??,"addr":"?�울 ?�초�?반포??19-1","type":"apartment","deposit":1_200_000_000,"rent":0,"grade":"A+","score":97,"lat":37.5085,"lng":127.0005,"size":84,"floor":"12/28�?,"year":2009,"insurable":True,"tags":["HUG가??,"SGI가??,"?�세?�출�???]},
    {"name":"?�?�팰리스 3�?2506??,"addr":"?�울 강남�??�곡??467","type":"mixed_use","deposit":1_500_000_000,"rent":0,"grade":"A+","score":99,"lat":37.4895,"lng":127.0455,"size":165,"floor":"25/69�?,"year":2004,"insurable":True,"tags":["HUG가??,"SGI가??,"?�세?�출�???]},
    {"name":"??�� ?�이?�크 805??,"addr":"?�울 강남�???��??702-10","type":"apartment","deposit":650_000_000,"rent":0,"grade":"A","score":91,"lat":37.5005,"lng":127.0365,"size":112,"floor":"8/25�?,"year":2017,"insurable":True,"tags":["HUG가??,"SGI가??,"?�세?�출�???]},
    {"name":"?�실 ?�스 106??503??,"addr":"?�울 ?�파�??�실??40","type":"apartment","deposit":900_000_000,"rent":0,"grade":"A+","score":98,"lat":37.5115,"lng":127.0815,"size":119,"floor":"5/35�?,"year":2008,"insurable":True,"tags":["HUG가??,"SGI가??,"?�세?�출�???]},
    {"name":"?�현??빌라 301??,"addr":"?�울 강남�??�현??245-3","type":"villa","deposit":350_000_000,"rent":500_000,"grade":"B+","score":76,"lat":37.5175,"lng":127.0285,"size":59,"floor":"3/4�?,"year":2015,"insurable":True,"tags":["SGI가??,"공증권장"]},
    {"name":"?�치동 ?�세?� 201??,"addr":"?�울 강남�??�치동 906-5","type":"multi_family","deposit":280_000_000,"rent":400_000,"grade":"B","score":71,"lat":37.4975,"lng":127.0625,"size":46,"floor":"2/4�?,"year":2008,"insurable":True,"tags":["SGI가??,"?�세가?�주??]},
    {"name":"방배??빌라 102??,"addr":"?�울 ?�초�?방배??794-2","type":"villa","deposit":180_000_000,"rent":600_000,"grade":"D","score":35,"lat":37.4815,"lng":126.9925,"size":33,"floor":"1/3�?,"year":2001,"insurable":False,"tags":["보증보험불�?","깡통?�험"]},
    {"name":"�?�� ?�이 1802??,"addr":"?�울 강남�?�?��??134-10","type":"apartment","deposit":1_000_000_000,"rent":0,"grade":"A","score":90,"lat":37.5205,"lng":127.0505,"size":99,"floor":"18/24�?,"year":2016,"insurable":True,"tags":["HUG가??,"SGI가??]},
]

LANDLORD_NAMES = ["김?�수","박재??,"?�정�?,"?�수??,"?��???,"?��???,"?�재??,"?�현??]


class Command(BaseCommand):
    help = '?�크???�드 ?�이???�성'

    def handle(self, *args, **options):
        self.stdout.write("?�드 ?�이???�성 ?�작...")

        # ?�사
        company, _ = Company.objects.get_or_create(
            business_number='123-45-67890',
            defaults={
                'name': '?�스??주식?�사',
                'representative': '?�?�이??,
                'address': '?�울??강남�??�스?�로 1',
                'loan_budget': 10_000_000_000,
                'loan_used': 9_700_000_000,
            }
        )

        # 관리자
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin', 'admin@workd.kr', 'admin1234', role='admin')

        # ?�차??(직원)
        tenant, _ = User.objects.get_or_create(
            username='tenant01',
            defaults={
                'email': 'tenant@workd.kr',
                'first_name': '직원',
                'last_name': '김',
                'role': 'tenant',
                'phone': '010-1234-5678',
                'is_verified': True,
                'company': company,
            }
        )
        if not tenant.has_usable_password():
            tenant.set_password('test1234')
            tenant.save()

        # 중개??        agent, _ = User.objects.get_or_create(
            username='agent01',
            defaults={
                'email': 'agent@workd.kr',
                'first_name': '중개',
                'last_name': '�?,
                'role': 'agent',
                'phone': '010-9999-0000',
                'is_verified': True,
            }
        )
        if not agent.has_usable_password():
            agent.set_password('test1234')
            agent.save()
        AgentProfile.objects.get_or_create(
            user=agent,
            defaults={
                'license_number': '11680-2024-00123',
                'office_name': '??�� 부?�산중개법인',
                'office_address': '?�울??강남�???���?45, 1�?,
                'office_phone': '02-555-1234',
            }
        )

        # ?��???+ 매물
        for i, prop_data in enumerate(SEED_PROPERTIES):
            landlord_name = LANDLORD_NAMES[i] if i < len(LANDLORD_NAMES) else f"?��???i}"
            username = f'landlord{i+1:02d}'

            landlord, _ = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': f'{username}@test.com',
                    'first_name': landlord_name[1:],
                    'last_name': landlord_name[0],
                    'role': 'landlord',
                    'phone': f'010-****-{1000+i}',
                    'is_verified': prop_data['score'] > 70,
                }
            )
            if not landlord.has_usable_password():
                landlord.set_password('test1234')
                landlord.save()

            LandlordProfile.objects.get_or_create(
                user=landlord,
                defaults={
                    'response_rate': min(95, 60 + prop_data['score'] * 0.3),
                    'avg_response_minutes': max(30, 300 - prop_data['score'] * 2),
                }
            )

            prop, created = Property.objects.get_or_create(
                name=prop_data['name'],
                defaults={
                    'address': prop_data['addr'],
                    'property_type': prop_data['type'],
                    'size_sqm': prop_data['size'],
                    'floor': prop_data['floor'],
                    'built_year': prop_data['year'],
                    'latitude': prop_data['lat'],
                    'longitude': prop_data['lng'],
                    'deposit': prop_data['deposit'],
                    'monthly_rent': prop_data['rent'],
                    'risk_grade': prop_data['grade'],
                    'risk_score': prop_data['score'],
                    'is_insurable': prop_data['insurable'],
                    'landlord': landlord,
                }
            )

            if created:
                tag_type_map = {
                    'HUG가??: 'positive', 'SGI가??: 'positive', '?�세?�출�???: 'positive',
                    '공증권장': 'warning', '?�세가?�주??: 'warning', '근�??�확?�필??: 'warning',
                    '보증보험불�?': 'danger', '깡통?�험': 'danger',
                }
                for tag_label in prop_data.get('tags', []):
                    PropertyTag.objects.create(
                        related_property=prop,
                        label=tag_label,
                        tag_type=tag_type_map.get(tag_label, 'positive')
                    )

        self.stdout.write(self.style.SUCCESS(
            f"?�료! 매물 {len(SEED_PROPERTIES)}�? ?��???{len(LANDLORD_NAMES)}�??�성"
        ))
